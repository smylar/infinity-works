import { Authority } from './authority';

/**
 * Data class describing an Authority collection 
 */
export class Authorities {
  authorities: Authority[];
}