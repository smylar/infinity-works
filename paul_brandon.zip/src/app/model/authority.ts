/**
 * Data class describing an Authority
 */
export class Authority {
  LocalAuthorityId: number;
  Name: string;
  RegionName: string;
}