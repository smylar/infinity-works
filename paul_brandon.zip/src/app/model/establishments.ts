import { Establishment } from './establishment';

/**
 * Data class describing an Establishment collection 
 */
export class Establishments {
    establishments: Establishment[] = [];
}